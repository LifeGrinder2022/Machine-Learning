Open this folder in PyCharm.
Select a Python 3 interpreter.
Install dependencies in the PyCharm terminal:
    python -m pip install -r requirements.txt
Run solution.py.
Keep the data folder beside solution.py. Results are generated in results/.
